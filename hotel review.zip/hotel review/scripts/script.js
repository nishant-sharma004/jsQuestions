$(document).ready(function () {
	
		
		 $.ajax({
		  dataType: "json",
		  url: "scripts/data.json",
		  success: function(d){
		  	data = d;
		  	addData(data);
		  	console.log(data)	
		  },
		  error:function(err){
		  	console.log(err)
		  }
		});//eof ajax call 


	function addData(data){
	
		$.each(data,function(key,val){
		$('<div>').append($('<h1>'+val.name+'</h1>').attr({"id":"name"+key,"class":"heading"}))
			.append($('<p>'+val.address+'</p>').attr("class","addr"))
			.append($('<span>').attr("id","price"+key))
			.append($('<span>').attr("id","rating"+key))
			.appendTo('.container');
		$('<div>').attr({"id":"desc"+key,"class":"hide"}).append('<h1>'+val.name+'</h1>')
		.append('<p>'+val.description+'</p>').appendTo(".popup");


		


		while(val.price){
			$('#price'+key).append('$')
			val.price--;
		}
		while(val.rating){
			$('#rating'+key).append('<span>&#9733</span>');
			val.rating--;
		}	
		

		});//end of each
		
		$('h1').click(function(event){
			var id = 	$(this).attr("id");
			$('body').attr("class","modalView");
			var index = id.slice(4,5);
			$('.popup>div').attr("class","hide");
			$('#desc'+index).attr("class","show");
		$(document).mousedown(function(event){
				$('.popup>div').attr("class","hide");
				$('body').removeClass("modalView");

			})
		});
	}//and of addData
 
});//end of document ready