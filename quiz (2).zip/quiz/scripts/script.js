$( document ).ready(function() {
var data = null;
   $.ajax({
  dataType: "json",
  url: "json/questions.json",
  success: function(d){
  	data = d;
  	addData(data)
}});//eof ajax call to get data from JSON
 function addData(data){
   	$.each(data, function(key,val){
   		$('<li/>').attr({'id':"question_"+key,'class':'questionsLi'}).append(val.question).appendTo('#list')
		addOptions(val.options,key);//calling addOptions() to add options next to respective question
   	})//eof each loop in addData()
   }//eof addData()
   function addOptions(optionsData,index){
   	$.each(optionsData, function(key,val){
		$('<p>').append($('<input/>',{
                'type': 'radio',
                'name': index+'options',
                'value': optionsData[key]
				})).append(optionsData[key]).appendTo('#question_'+index)
   	})//eof each loop in addOptions()
   }//eof addOptions()
  $('#submitBtn').click(function(){
  	var count=0;
  	$.each(data, function(key,val){
    if ($("input:radio[name=" +key +'options'+ "]:checked").val() == val.answer)
  			count+=1;	
  	})//eof each loop in submitBtn()
      $('#score').empty();//removing the previous score
  	 $('#score').append(count);
  })//eof submitBtn click()
});//eof ready()