
$(document).ready(function() {
  var data = null;
  var b = [];
  var spanStar="";
    $(".songList").click(function() {
            $(".song_list").show();
            $(".add_songs").hide();
            $('.row').empty();
            init();
        }) //eof songList()

    $(".addSong").click(function(){
      addSongSubfun()
    });

        

    function addSongSubfun(){

      $(".song_list").hide();
            $(".add_songs").show();
           var id = null;
            ratingForSongs(id);

             $('.ratingStars').click(function(){
             id = this.id;
             ratingForSongs(id);
           });

    }


    function ratingForSongs(id){
        var s="";
      for(var i=0;i<5;i++){

        if(i>id || id==null)
          s+="<span id="+i+" class=ratingStars>&#9734;</span>";
        else
        s+="<span id="+i+" class=ratingStars>&#9733;</span>";
      }
      spanStar = s;
      $('#rate').empty();
      $('#rate').append(s)

    }//eof ratingForSongs()




    $('.save').click(function() {

        var a = {
            "name": $('#song').val(),
            "artist": $('#artistIn').val(),
            "album": $('#albumIn').val(),
            "rating":spanStar
        }

        if (window.localStorage.getItem("add-song") == null) {
            b = [];
            b.push(a);
            window.localStorage.setItem("add-song", JSON.stringify(b))
        } else {
            b = JSON.parse(window.localStorage.getItem("add-song"));
            b.push(a)
            window.localStorage.setItem("add-song", JSON.stringify(b))
        }

        var r = confirm("Save Successful \n Do you want to add another song");
        if (r) {
               $('#song').val('')
                $('#artistIn').val('')
                $('#albumIn').val('')
                addSongSubfun();//calling back the add song function to display the add song page back

        } else {
            $(".song_list").show();
            $(".add_songs").hide();
            init();
           // addArtistnAlbumOptions();
        }

        $('.cancel').click(function() {
            $('#song').val(''),
                $('#artistIn').val(''),
                $('#albumIn').val('')

        }); //eof cancel click()

    }); //eof save click()

    $('.arrowDown').click(function() {
            sortArayObjects(b, $(this).parent().attr('id'), 1)
        }) //eof of arrowDown Click()

    $('.arrowUp').click(function() {
            sortArayObjects(b, $(this).parent().attr('id'), 0)
        }) //eof of arrowUp Click()

    $('.box').keyup(function() {
        var s = $('.box').val();
        var f = [];
        $.each(b, function(key, val) {
         
            if(val.name.match(s)){
                f.push(val)
            }
        })
        if (f[0] != null)
            display(f);

    }); //search box


    function addArtistnAlbumOptions() {
        $('#artistOption').empty();
        $('#albumOption').empty();
        var artistArray =[];
        var albumArray=[];
$.each(b, function(i, item){
  if ($.inArray(item.artist, artistArray) === -1)
    artistArray.push(item.artist);
  if ($.inArray(item.album, albumArray) === -1)
    albumArray.push(item.album);
});

        $.each(artistArray, function(i, item) {
          
            $('#artistOption').append($('<option>', {
                value: item,
                text: item
            }));
            });//eof each loop
          
          $.each(albumArray, function(i, item) {
            $('#albumOption').append($('<option>', {
                value: item,
                text: item
            }));
          });//eof each loop
        
    }

    $('#artistOption , #albumOption').on('change', function() {
        var artAlb = this.value;
        $('.row').empty();
        $.each(b, function(key, val) {
                if (artAlb == val.artist || artAlb == val.album) {
                    $('<tr>').attr('class', 'row').append($('<td>').html(val.name)).append($('<td>').text(val.artist)).append($('<td>').text(val.album)).append($('<td>').html(val.rating)).appendTo(".tab");
                }
            }) //eof each in change()
    }); //change()

    function sortArayObjects(arr, item, w) {
            var c = arr.sort(function(obj1, obj2) {
                if (w == 0) {
                    console.log(item)
                    return ((obj1[item].toLowerCase() > obj2[item].toLowerCase()) ? -1 : ((obj1[item].toLowerCase() < obj2[item].toLowerCase()) ? 1 : 0));
                }
                if (w == 1) {
                    console.log(item)
                    return ((obj1[item].toLowerCase() < obj2[item].toLowerCase()) ? -1 : ((obj1[item].toLowerCase() > obj2[item].toLowerCase()) ? 1 : 0));
                }
            })
            display(c)
        } //sortArayObjects()

    function display(c) {
        $('.row').empty();
        $.each(c, function(key, val) {
                $('<tr>').attr('class', 'row').append($('<td>').html(val.name)).append($('<td>').text(val.artist)).append($('<td>').text(val.album)).append($('<td>').html(val.rating)).appendTo(".tab");
            }) //eof each
    }

    function init() {
        $('.row').empty()
        b = JSON.parse(window.localStorage.getItem("add-song"));
        $.each(b, function(key, val) {
                $('<tr>').attr('class', 'row').append($('<td>').html(val.name)).append($('<td>').html(val.artist)).append($('<td>').html(val.album)).append($('<td>').html(val.rating)).appendTo(".tab");
            }) //eof each
        addArtistnAlbumOptions();

    }//eof init()s
    init();
});